package mx.edu.itesca.practica6

class Product ( var name:String,
                var image: Int,
                var description:String,
                var price:Double  )
